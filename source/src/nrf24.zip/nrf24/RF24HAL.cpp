/*
 * RF24HAL.cpp
 *
 *  Created on: 4 ���. 2018 �.
 *      Author: Bogdan
 */

#include <hal.h>

#include "RF24HAL.h"

